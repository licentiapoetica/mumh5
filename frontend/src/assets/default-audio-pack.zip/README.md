# Chatterbox Turbo voice pack

134 WAV clips using voice `female`. Generated locally, one file at a time.

Audio: mono, native 24 kHz, 16-bit PCM WAV. Model watermarking remains enabled.

`manifest.json` records the exact texts, model revision, voice sample hash, actual device and seed, generation settings and output hashes.

Mumble core events can use static sounds in the client settings. Extra API events and state variants require a plugin or API bridge. The project pack README documents the event mapping.
